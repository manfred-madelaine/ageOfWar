#include "Terrain.hpp"

Terrain::Terrain(int nbCases): m_nbCases(nbCases), m_baseA(2), m_baseB(2)
{

}

Terrain::~Terrain()
{
    //dtor
}


void Terrain::newTour()
{
    m_baseA.addGold(8);
    m_baseB.addGold(8);
    //cout << "New tour:\n\tbase A(" << &m_baseA << ") +8 gold -> " << m_baseA.Getgold() << endl;
//    cout << &m_baseB << "  new tour:\n\tbase B +8 gold -> " << m_baseA.Getgold() << endl;
}

void Terrain::supprimerUnite(Unite *u)
{
    for(unsigned int i= 0; i < tab.size(); i++)
    {
        if(u->Getpos() == tab[i]->Getpos())
        {
//            tab.erase(i);
        }
    }
}

void Terrain::afficherTab()
{
    cout<<endl<<"Affichage tableau du terrain"<<endl;
    for(unsigned int i=0;i<tab.size();i++){
        cout<<tab[i]->toString()<<endl;
    }
    cout<<"Fin affichage tableau du terrain"<<endl<<endl;
}

void Terrain::trierTabCroissant(){
    unsigned int ok=0;
    while(ok!=tab.size()){
        int maxVal=tab[ok]->Getpos();
        unsigned int max=ok;
        for(unsigned int i=ok+1;i<tab.size();i++){
            if(maxVal<tab[i]->Getpos()){
                maxVal=tab[i]->Getpos();
                max=i;
            }
        }
        if(max!=ok){
            Unite *tmp= tab[ok];
            tab[ok]=tab[max];
            tab[max]=tmp;

        }
        ok+=1;
    }
}

