#include "stdafx.h"

// Stdafx.hpp: fichier source qui int�gre simplement les normes du jeu.
