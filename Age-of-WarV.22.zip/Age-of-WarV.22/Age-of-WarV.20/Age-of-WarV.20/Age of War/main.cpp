#include <iostream>
#include <fstream>

#include "Affichage.hpp"
#include "Partie.hpp"

using namespace std;

int main()
{
    Partie p = Partie();
    p.play();
    return 0;
}
